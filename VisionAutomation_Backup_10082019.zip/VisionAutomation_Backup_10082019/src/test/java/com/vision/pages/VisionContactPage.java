package com.vision.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VisionContactPage {

	WebDriver driver;

	//Constructor for VisionContactPage

	
	public VisionContactPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//Name field
	@FindBy(xpath = "//*[@id=\"author\"]")
	WebElement nameField;
	
	//Email field
	@FindBy(id = "email")
	WebElement emailField;
	
	//Subject field
	@FindBy(name = "url")
	WebElement subjectField;
	
	//Message field
	@FindBy(xpath = "//*[@id=\"comment\"]")
	WebElement messageField;
	
	//Submit button
	@FindBy(xpath = "//*[@id=\"submit\"]")
	WebElement submitBtn;
	
	
	//submit form method
	
//	public void submitForm() 
//	{
//		nameField.sendKeys("peter");
//		emailField.sendKeys("peter@gmail.com");
//		subjectField.sendKeys("nothing");
//		messageField.sendKeys("message");
//		//submitBtn.click();
//	}
	
	//submit form method
			public void submitForm(String name, String email, String subject, String message) 
			{
				nameField.sendKeys(name);
				emailField.sendKeys(email);
				subjectField.sendKeys(subject);
				messageField.sendKeys(message);
				//submitBtn.click();
			}
}
