package com.vision.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VisionCareersPage {

	WebDriver driver;

	// Constructor for VisionCareersPage
	public VisionCareersPage(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// locate view open positions button
	@FindBy(xpath="//*[@id=\"fusion-slider-78\"]/div/ul/li/div[1]/div/div[3]/div/div/a")
	WebElement viewOpenPositionBtn;	
	
	
	//Locate keyword field
	@FindBy(name = "search_keywords")
	WebElement keywardField;
	
	//locate location field
	@FindBy(id = "search_location")
	WebElement locationField;
	
    //open position button click method
	public void viewOpenPositionBtnClick()
	{
		viewOpenPositionBtn.click();
	}
	
	//enter keyword 
	public void enterKeyword(String JobSearchKeyword)
	{
		keywardField.sendKeys(JobSearchKeyword);
	}
	
	//enter location
	public void enterLocation(String location)
	{
		locationField.sendKeys(location);
	}
	
	//search job
	public void searchJob()
	{
		this.viewOpenPositionBtnClick();
		this.enterKeyword("developer in test");
		this.enterLocation("dundee");
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ENTER);
		
	}
}
