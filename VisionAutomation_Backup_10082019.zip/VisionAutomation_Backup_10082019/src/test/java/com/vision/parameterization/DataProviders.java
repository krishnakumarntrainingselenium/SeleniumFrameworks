package com.vision.parameterization;

import java.io.IOException;

import org.testng.annotations.DataProvider;

import com.vision.utilities.DataReader;
import com.vision.utilities.ExcelReader;
import com.vision.utilities.SystemUrls;

public class DataProviders {
	
	public static ExcelReader excel=null;
	
    @DataProvider
	public static Object[][] visionFirstTCData() throws IOException
	{
		 DataReader data=new DataReader();
		 String getdata[][]=data.getsheetvalue(SystemUrls.VISION_INPUT, SystemUrls.VISION_INPUT_Login);
		 
		 String dp_name=getdata[1][0];
		 String dp_email=getdata[1][1];
		 String dp_subject=getdata[1][2];
		 String dp_message=getdata[1][3];
		 System.out.print(dp_name +" "+dp_email+" "+dp_subject+" "+dp_message);
		 //String name, String email, String subject, String message
		 //String newpassword=getdata[11][2];
		 
	     return new Object[][]
	    { 
	    	 new String[] {dp_name,dp_email,dp_subject,dp_message} 
		 };	
	}
	
//	//TestCase
//	@Test(dataProvider="getDataFromExcel")
//	public void testdata1(Hashtable<String,String> data)
//	{
//		System.out.println(data.get("Header1")+"---"+data.get("Header2")+"------"+data.get("Header3")+"-----"+data.get("Header4"));
//	}
	
//	//DataProvider
//	@DataProvider
//	public static Object[][] getDataFromExcel()
//	{
//		if(excel==null)
//		{
//			excel=new ExcelReader("D:\\Learning_Tools\\Eclipse\\Eclipse_EE_Dev_Workspace\\Selenium_Frameworks_Archive_Workspace\\visionproject\\src\\test\\resources\\excel\\TestNGdata.xlsx");
//		}
//		
//		String sheetName="Login";
//				
//		int rows=excel.getRowCount(sheetName);	
//		int cols=excel.getColumnCount(sheetName);	
//		
//		Object[][] data=new Object[rows-1][1];
//		
//		Hashtable<String,String> table=null;
//				
//		for(int rownum=2;rownum<=rows;rownum++)
//		{
//			table=new Hashtable<String,String>();
//			
//			for(int colnum=0;colnum<=cols;colnum++)
//			{
//				table.put(excel.getCellData(sheetName, colnum, 1),excel.getCellData(sheetName, colnum, rownum));
//				
//				data[rownum-2][0]=table;
//		}
//		}
//		return data;
//	}
		
			
	}
