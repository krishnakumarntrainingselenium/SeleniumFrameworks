package com.vision.utilities;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class DataReader 
{
	 FileInputStream fi;
	 XSSFWorkbook workbook;
	 XSSFSheet sheet;
	 XSSFCell Cell;
	 XSSFRow row;
	 
	public  String[][] getsheetvalue(String filename, String Sheetname) throws IOException
	{      
		 fi=new FileInputStream(filename);
	     workbook=new XSSFWorkbook(fi);
	     sheet=workbook.getSheet(Sheetname);
	     int LastRownum=sheet.getLastRowNum();
	       
         //System.out.println(LastRownum);
         String datsheet[][] = new String[LastRownum+1][100];
         
         //Navigating rows and columns and collecting data from entire sheet
         for (int row = 0; row <= sheet.getLastRowNum(); row++) 
         {  
	       	  // System.out.println("hello");
	    	  // System.out.println("colum count"+sheet.getRow(row).getLastCellNum());
	    	  
	           for (int col = 0; col<sheet.getRow(row).getLastCellNum(); col++) 
	           {
         	    //System.out.print(row);
			   // System.out.print(col);
	  	        
				    if((sheet.getRow(row).getCell(col))==null) 
				    {		    
				    	datsheet[row][col]=null;
				    	System.err.println(datsheet[row][col]);	   
	    	        }
	    	        else 
	    	        {
//	    	    	sheet.getRow(row).getCell(col).setCellType(Cell.CELL_TYPE_STRING);
	    	        sheet.getRow(row).getCell(col).setCellType(CellType.STRING);
	    	    	datsheet[row][col]=sheet.getRow(row).getCell(col).getStringCellValue();
	    	    	 //System.err.println(datsheet[row][col]);
	    	        }	//	
	    	   }	    		  
	       }  
	       return datsheet; 
	 } 

	
	public  String[][] getdataprovider(String filename, String Sheetname,int columsize) throws IOException
	{      
		   fi=new FileInputStream(filename);
	       workbook=new XSSFWorkbook(fi);
	       sheet=workbook.getSheet(Sheetname);
	       int LastRownum=sheet.getLastRowNum();
	      
	       System.out.println(LastRownum);
	       String datsheet[][] = new String[LastRownum+1][columsize];
          
	       for (int row = 0; row <=sheet.getLastRowNum(); row++) 
	       {  
	    
	    	  System.out.println("colum count"+sheet.getRow(row).getLastCellNum());
	    	  for (int col = 0; col<sheet.getRow(row).getLastCellNum(); col++)	    		
	    	  {
	    		    System.out.print(row);
				    System.out.print(col);
				    
				    if((sheet.getRow(row).getCell(col))==null) 
				    {
					    datsheet[row][col]=null;
		    		    System.err.println(datsheet[row][col]);
				    }		   					   
	                else 
	                {
		    		sheet.getRow(row).getCell(col).setCellType(CellType.STRING);
		    		datsheet[row][col]=sheet.getRow(row).getCell(col).getStringCellValue();
		    		System.err.println(datsheet[row][col]);
	                }	    					    	
	    	    }
	    		  
	       } 	    	  
	 	  return datsheet;	  
	}   

	 /* public static void main(String args[]) throws IOException
	  {
		  new DataReader().getsheetvalue(System.getProperty("user.dir").concat("\\src\\main\\java\\com\\tos\\dataprovider\\Khelid_inputs.xlsx"), "Happy_FLow_data");		  
	  }
	    	*/
}
