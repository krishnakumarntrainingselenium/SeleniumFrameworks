package com.vision.testcases;

//import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.vision.pages.VisionContactPage;
import com.vision.pages.VisionHomePage;

public class VisionFirstTestCase extends TestBase {

//  public static WebDriver driver=null;
	VisionHomePage visionHomePage;
	VisionContactPage visionContactPage;
	
	@Parameters({"OS","Browser"})
	@BeforeTest
	public void openBrowser(String OS, String Browser) throws InterruptedException {
		System.out.println(Browser);
		super.setup(OS, Browser);
		visionHomePage = new VisionHomePage(driver);
		visionContactPage = new VisionContactPage(driver);
	}

	@AfterTest
	public void closeBrowser() {
		driver.close();
	}

//    @Test(priority = 0) 
////    @Test
//    public void visionContactTC1() {
//    	visionHomePage.contactLinkClick();
//    	//visionContactPage.submitForm();
//    }
//
//    @Test(priority = 1)
//    public void visionContactTC2() {
//    	visionContactPage.submitForm();


@Test(dataProvider="visionFirstTCData",dataProviderClass=com.vision.parameterization.DataProviders.class)
public void visionContactTC1(String name, String email, String subject, String message) throws InterruptedException {
	visionHomePage.contactLinkClick();
	Thread.sleep(1000);
	visionContactPage.submitForm(name,email,subject,message);
	Thread.sleep(1000);


}
}
