package com.vision.testcases;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.vision.pages.VisionCareersPage;
import com.vision.pages.VisionContactPage;
import com.vision.pages.VisionHomePage;

public class SearchJobTC extends TestBase {

//  public static WebDriver driver=null;
	VisionHomePage visionHomePage;
	VisionCareersPage visionCareersPage;

 	@Parameters({"OS","Browser"})
	@BeforeTest
	public void openBrowser(String OS, String Browser) throws InterruptedException {
		super.setup(OS, Browser);
		 visionHomePage = new VisionHomePage(driver);
	     visionCareersPage = new VisionCareersPage(driver);
	}
    
    @AfterTest
    public void closeBrowser() 
    {
        driver.close();
    }
    @Test
    public void searchJobTestCase() throws InterruptedException
    {
    	visionHomePage.popupAcceptBtnClick();
    	Thread.sleep(1000);
    	visionHomePage.careersLinkclick();
    	Thread.sleep(1000);
    	visionCareersPage.searchJob();
    	Thread.sleep(1000);
    	//Assert.assertTrue(driver.findElement(By.xpath("//*[@id='post-12984']/div/div[3]/div/div/div/div[4]/div/ul/li/a/div[1]/h3")).isDisplayed());
        String expectedMessage = "Developer in test";
        //String actualMessage = driver.findElement(By.xpath("//div[contains(@class,'position')]").;
        
        WebElement a=driver.findElement(By.xpath("//*[@id='post-12984']/div/div[3]/div/div/div/div[4]/div/ul/li/a/div[1]/h3"));
      
        Thread.sleep(1000);
        //Assert.assertTrue(a.getAttribute("value").equals("Developer in test"));
        System.out.print(a.getText());
        System.out.print(a.getAttribute("value"));
        		
//        		getAttribute("text"));
//        Assert.assertTrue(a.getAttribute("value").matches("*Developer in test*"));
        
//        Assert.assertEquals(actualMessage, expectedMessage);
        
    	
    }
	
}
