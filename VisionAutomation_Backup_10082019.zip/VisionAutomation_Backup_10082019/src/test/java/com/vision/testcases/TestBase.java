package com.vision.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestBase {
	
    public static WebDriver driver=null;


    public void setup(String OS, String browser) throws InterruptedException {
    	
    	System.out.print(browser);
    	if(browser.equals("chrome")) {
	    	//System.setProperty("Webdriver.chrome.driver", "C:\\Users\\narayanasamy\\Desktop\\Chrome Driver.exe");
    		
	    	System.setProperty("Webdriver.chrome.driver",System.getProperty("user.dir").concat("/src/test/resources/executables/chromedriver.exe"));
	    	
			driver = new ChromeDriver();
		}
    	else if(browser.equals("firefox")) {
	    	//System.setProperty("Webdriver.gecko.driver", "C:\\Users\\narayanasamy\\Desktop\\geckodriver.exe");
	    	//System.setProperty("Webdriver.gecko.driver", "C:\\Users\\narayanasamy\\Desktop\\selenium lessons\\geckodriver.exe");
	    	System.setProperty("Webdriver.gecko.driver",System.getProperty("user.dir").concat("/src/test/resources/executables/geckodriver.exe"));
	    	
			driver = new FirefoxDriver();
    	}
    	

		driver.get("https://www.visionhealth.co.uk");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		

     
    }
}