package com.vision.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VisionHomePage {

	public WebDriver driver;

	// Constructor for VisionHomePage
	public VisionHomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//*[@id='hs-eu-confirmation-button']")
	WebElement acceptBtn;

	// locate home link
	@FindBy(xpath="//*[@id='menu-item-11850']/a/span")
	WebElement visionHomeLink;

	// locate vision link
	@FindBy(xpath = "//*[@id='menu-item-11851']/a/span")
	WebElement visionLink;

	// locate Events link
	@FindBy(xpath = "//*[@id='menu-item-11852']/a/span")
	WebElement eventsLink;

	// locate blog link
	@FindBy(xpath = "//*[@id='menu-item-11854']/a/span")
	WebElement blogLink;

	// locate contact link
	@FindBy(xpath = "//*[@id='menu-item-11856']/a/span")
	WebElement contactLink;

	// locate careers link
	@FindBy(xpath = "//*[@id='menu-item-13562']/a/span")
	WebElement careersLink;

	// locate Hive button
	@FindBy(xpath = "//*[@id='menu-item-12065']/a/span")
	WebElement hiveButton;

	// click on vision home link
	public void homeClick() {
		visionHomeLink.click();
	}

	// click on vision link
	public void visionClick() {
		visionLink.click();
	}

	// click on events link
	public void eventsLink() {
		eventsLink.click();
	}

	// click on blog link
	public void blogsLink() {
		blogLink.click();
	}

	// click on contact link
	public void contactLinkClick() {
		acceptBtn.click();
		contactLink.click();
	}

	// click on careers link
	public void careersLinkclick() {
		careersLink.click();
	}

	// click on hive button
	public void hiveButton() {
		hiveButton.click();
	}

}
