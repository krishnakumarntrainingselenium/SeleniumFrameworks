package com.vision.utilities;

import com.vision.testcases.TestBase;

public class SystemUrls extends TestBase
{
	//Excel File Location
	public final static String VISION_INPUT=System.getProperty("user.dir").concat("\\src\\test\\resources\\excel\\TestNGdata.xlsx");
//	D:\Learning_Tools\Eclipse\Eclipse_EE_Dev_Workspace\Selenium_Frameworks_Archive_Workspace\visionproject\src\test\resources\excel\TestNGdata.xlsx
//	D:\Learning_Tools\Eclipse\Eclipse_EE_Dev_Workspace\Selenium_Frameworks_Archive_Workspace\visionprojectsrc\test\resources\excel\TestNGdata.xlsx 
	//SheetName
	public final static String VISION_INPUT_Login="Login"; 
	
//  public final static String Webhook="https://hooks.slack.com/services/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";
//  public final static String slack_token="xoxp-279208641302-277680148912-291657567892-1ab11154438a20e18b5f50246b25d28e";
//  public final static String slack_channel="#tosautomation";
	
//  public final static String browser=property.getProperty("Browser");
//	public final static String KHEL_ID_INPUT_Login="Login";
	
////	Added by kk 16/03/2018
//	public final static String KHEL_ID_INPUT_tournamentplayercheck=System.getProperty("user.dir").concat("//src//main//java//com//tos//dataprovider//Khelid_inputs_tournamentplayercheck.xlsx");
//	public final static String KHEL_ID_INPUT_tournamentcheckSummary="Tournamentcheck_Summary";           
//	End - Added by kk 16/03/2018



}
