package com.vision.testcases;

import java.util.Hashtable;

//import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.vision.pages.VisionContactPage;
import com.vision.pages.VisionHomePage;

public class VisionFirstTestCase extends TestBase{
	
//	@Test(dataProvider="getDataFromExcel")
//	public void testdata1(Hashtable<String,String> data)
//	{
//		System.out.println(data.get("Header1")+"---"+data.get("Header2")+"------"+data.get("Header3")+"-----"+data.get("Header4"));
//	}

	VisionHomePage visionHomePage;
	VisionContactPage visionContactPage;

    @BeforeTest
    public void setup() throws InterruptedException {
        super.setup();
        visionHomePage = new VisionHomePage(driver);
        visionContactPage = new VisionContactPage(driver);
    }
    
    @AfterTest
    public void closeBrowser() 
    {
        driver.close();
    }
       

    @Test(dataProvider="visionFirstTCData",dataProviderClass=com.vision.parameterization.DataProviders.class)
    public void visionContactTC1(String name, String email, String subject, String message) {
    	visionHomePage.contactLinkClick();
//    	String name = null;
//		String email = null;
//		String subject = null;
//		String message = null;
		visionContactPage.submitForm(name,email,subject,message);
    	 
    }
    
    
//    @Test(priority=7,dataProvider="changepass_data",dataProviderClass=com.tos.dataprovider.Dataproviderone.class)
//    public void changepassword(String email_address, String old_pass,String new_pass) throws IOException, SQLException, InterruptedException 
//    {    
//  	 
//  	  //String ActualKhelid=db.getkhel_id(email_address);
//  	   
//  	   launch=new KhelidLandingpage(driver);
//  	   login=launch.Clickon_Login();
//  	   login.login(email_address, old_pass);
//  	   player=new Player_dashboard(driver);
//  	   changepass=player.click_changepassword();
//  	   player=changepass.changepassword(email_address,old_pass,new_pass);
    
    
//  @Test(priority = 0) 
//  public void visionContactTC1(Hashtable<String,String> data) {
//  	visionHomePage.contactLinkClick();
//  	visionContactPage.submitForm();
//  }

//    @Test(priority = 1)
//    public void visionContactTC2() {
//    	visionContactPage.submitForm();
//    }


}
