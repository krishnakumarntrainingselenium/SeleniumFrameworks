package com.vision.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class TestBase {
	
    public static WebDriver driver=null;


    public void setup() throws InterruptedException {
    	System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Krishna Kumar N\\Desktop\\Selenium\\Selenium setup_Running\\Chrome Driver.exe");
		driver = new ChromeDriver();

		driver.get("https://www.visionhealth.co.uk");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

     
    }
}
